(() => {
  "use strict";

  const STORAGE = "auction-manager-v1";
  const $ = id => document.getElementById(id);

  const defaultState = {
    settings: { tournamentName:"Cricket Auction", totalPoints:1200, playersRequired:8, minimumBid:30 },
    teams: [],
    history: []
  };

  let state = load();

  function load(){
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE));
      return saved && saved.settings && Array.isArray(saved.teams) ? saved : structuredClone(defaultState);
    } catch { return structuredClone(defaultState); }
  }
  function save(){ localStorage.setItem(STORAGE, JSON.stringify(state)); }
  function money(n){ return Math.max(0, Math.floor(Number(n)||0)); }

  // Core rule:
  // max legal bid = remaining points - minimum reserve for every player slot
  // that must remain AFTER this purchase.
  function maxBid(team){
    const remaining = team.points;
    const playersLeftAfterPurchase = Math.max(0, state.settings.playersRequired - (team.players.length + 1));
    return Math.max(0, remaining - state.settings.minimumBid * playersLeftAfterPurchase);
  }
  function reserve(team){
    const slotsLeft = Math.max(0, state.settings.playersRequired - team.players.length);
    return slotsLeft * state.settings.minimumBid;
  }
  function getTeam(id){ return state.teams.find(t => t.id === id); }

  function render(){
    $("appTitle").textContent = state.settings.tournamentName || "Auction Manager";
    $("totalPoints").value = state.settings.totalPoints;
    $("playersRequired").value = state.settings.playersRequired;
    $("minimumBid").value = state.settings.minimumBid;
    $("tournamentName").value = state.settings.tournamentName;

    $("teamCount").textContent = `${state.teams.length} team${state.teams.length===1?"":"s"}`;

    const options = state.teams.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join("");
    $("winningTeam").innerHTML = options || `<option value="">Add a team first</option>`;
    $("teamSelector").innerHTML = options || `<option value="">Add a team first</option>`;

    $("adminTeams").innerHTML = state.teams.length ? state.teams.map(t => `
      <div class="team-row">
        <div><div class="team-name">${esc(t.name)}</div><div class="sub">${t.players.length}/${state.settings.playersRequired} players · reserve ${reserve(t)} pts</div></div>
        <div class="team-stat"><strong>${t.points}</strong><div class="sub">Max bid ${maxBid(t)}</div></div>
      </div>`).join("") : `<div class="empty">No teams yet. Add the tournament teams above.</div>`;

    $("history").innerHTML = state.history.length ? state.history.slice().reverse().map(h => `
      <div class="history-row">
        <div><strong>${esc(h.player)}</strong><div class="sub">${esc(h.teamName)}</div></div>
        <div class="price">${h.price} pts</div>
      </div>`).join("") : `<div class="empty">No sales yet.</div>`;

    renderTeam();
  }

  function renderTeam(){
    const team = getTeam($("teamSelector").value) || state.teams[0];
    if (!team){
      $("teamDashboard").innerHTML = `<div class="card empty">Add teams from Admin View to see a team dashboard.</div>`;
      return;
    }
    $("teamSelector").value = team.id;
    const total = state.settings.totalPoints;
    const spent = total - team.points;
    const pct = Math.min(100, Math.max(0, spent / total * 100));
    const reservePts = reserve(team);
    const max = maxBid(team);
    $("teamDashboard").innerHTML = `
      <div class="hero team-hero">
        <div class="eyebrow">TEAM LIMIT</div>
        <h2>${esc(team.name)}</h2>
        <div class="sub">Remaining points</div>
        <div class="balance">${team.points}</div>
        <div class="metrics">
          <div class="metric"><span>MAX NEXT BID</span><b>${max}</b></div>
          <div class="metric"><span>PLAYERS</span><b>${team.players.length}/${state.settings.playersRequired}</b></div>
          <div class="metric"><span>RESERVE NEEDED</span><b>${reservePts}</b></div>
        </div>
        <div class="progress"><div style="width:${pct}%"></div></div>
        <div class="sub">${spent} points spent</div>
        ${team.players.length >= state.settings.playersRequired ? `<div class="alert">Player quota complete. No more players can be purchased.</div>` : ""}
      </div>
      <div class="card">
        <h2>Players Bought</h2>
        ${team.players.length ? `<ul class="player-list">${team.players.map((p,i)=>`<li><span>${i+1}. ${esc(p.name)}</span><strong>${p.price} pts</strong></li>`).join("")}</ul>` : `<div class="empty">No players bought yet.</div>`}
      </div>`;
  }

  function applySettings(){
    const total = money($("totalPoints").value);
    const required = Math.max(1, Math.floor(money($("playersRequired").value)));
    const min = Math.max(1, Math.floor(money($("minimumBid").value)));
    if (!total || !required || !min) return alert("Settings must be greater than zero.");
    state.settings = { tournamentName: $("tournamentName").value.trim() || "Cricket Auction", totalPoints:total, playersRequired:required, minimumBid:min };
    state.teams.forEach(t => {
      const spent = t.players.reduce((s,p)=>s+p.price,0);
      t.points = Math.max(0,total-spent);
    });
    save(); render();
  }

  function addTeam(){
    const name = $("newTeamName").value.trim();
    if(!name) return alert("Enter a team name.");
    if(state.teams.some(t=>t.name.toLowerCase()===name.toLowerCase())) return alert("That team already exists.");
    state.teams.push({id:"team_"+Date.now()+"_"+Math.random().toString(36).slice(2,7),name,points:state.settings.totalPoints,players:[]});
    $("newTeamName").value="";
    save(); render();
  }

  function sellPlayer(){
    const player = $("currentPlayer").value.trim();
    const team = getTeam($("winningTeam").value);
    const price = Math.floor(Number($("soldPrice").value));
    if(!player) return $("adminMessage").textContent="Enter the player name.";
    if(!team) return $("adminMessage").textContent="Add/select a winning team.";
    if(!Number.isFinite(price) || price < state.settings.minimumBid) return $("adminMessage").textContent=`Minimum bid is ${state.settings.minimumBid} points.`;
    if(team.players.length >= state.settings.playersRequired) return $("adminMessage").textContent="This team has completed its player quota.";
    const legalMax = maxBid(team);
    if(price > legalMax) return $("adminMessage").textContent=`${team.name}'s maximum legal bid is ${legalMax} points.`;
    team.points -= price;
    team.players.push({name:player,price});
    state.history.push({player,teamId:team.id,teamName:team.name,price});
    $("currentPlayer").value=""; $("soldPrice").value="";
    $("adminMessage").textContent=`${player} sold to ${team.name} for ${price} points.`;
    save(); render();
  }

  function undo(){
    const h = state.history.pop();
    if(!h) return;
    const team = getTeam(h.teamId);
    if(team){
      const idx = team.players.map(p=>p.name+"|"+p.price).lastIndexOf(h.player+"|"+h.price);
      if(idx>=0) team.players.splice(idx,1);
      team.points += h.price;
    }
    save(); render();
    $("adminMessage").textContent=`Undid ${h.player}'s sale.`;
  }

  function resetAll(){
    if(!confirm("Reset the entire auction? All teams and sales will be deleted.")) return;
    state = structuredClone(defaultState); save(); render();
  }

  function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

  document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click",()=>{
    document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));
    document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.view+"View").classList.add("active");
  }));
  $("saveSettings").addEventListener("click",applySettings);
  $("addTeam").addEventListener("click",addTeam);
  $("sellPlayer").addEventListener("click",sellPlayer);
  $("undoSale").addEventListener("click",undo);
  $("resetAll").addEventListener("click",resetAll);
  $("teamSelector").addEventListener("change",renderTeam);

  render();
})();