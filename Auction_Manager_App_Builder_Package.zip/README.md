# Auction Manager — App Builder Package

## What is included
- `index.html` — mobile-first app UI
- `styles.css` — responsive styling
- `app.js` — complete auction logic
- `DATA_MODEL.json` — recommended data structure for connecting a backend
- `README.md` — implementation notes

## Current auction rules
Default:
- Total team points: 1200
- Players required: 8
- Minimum bid: 30
- Maximum initial legal bid: 960

The maximum legal bid is calculated dynamically:
`remaining_points - (minimum_bid × players_required_after_this_purchase)`

Example:
1200 points, 8 players, 30 minimum bid:
1200 - (30 × 7) = 990 for the first purchase if the player being purchased is the first slot.

IMPORTANT:
If your intended rule is that 240 points must always be reserved for all 8 players BEFORE any bidding, then the initial maximum must instead be fixed at 960. In the current app, the mathematically standard auction rule reserves points for the players that remain AFTER the current purchase.

## Admin view
- Change tournament settings
- Add teams
- See every team's balance and maximum bid
- Select winning team
- Enter sold player and price
- Mark player sold
- Undo last sale
- View complete auction history

## Team view
- Select a team
- Remaining points
- Maximum next legal bid
- Players bought / required
- Reserve points
- Spending progress
- Player list

## Current storage
This version uses browser local storage for testing. It is NOT a live multi-device system yet.

## Production/live version
For multiple phones to update live, connect the UI to a backend such as Firebase/Supabase or another realtime database.

Recommended collections/tables:
- tournaments
- teams
- players
- sales
- team_members / team_access

The admin should be the only role allowed to change settings and record sales. Team users should have read-only access to their own team record.

## Suggested app-builder mapping
If your app builder accepts HTML/CSS/JavaScript, import the three source files.
If it requires separate screens:
- Screen 1: Admin dashboard
- Screen 2: Team dashboard
- Screen 3: Team login/access
- Screen 4: Auction history

For a true production app, replace the localStorage functions in `app.js` with realtime database reads/writes and server-side validation.
